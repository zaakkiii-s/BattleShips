import java.util.Scanner;
import java.util.Random;

//FIVE ships are placed in battle ships 

public class BattleShips {

    private char[][] grid = new char [10][10];
 
    //TODO: Add your code here
    
    public BattleShips() {
    	placeShips();
    }
    
    //This method is only used within class so it is set to private
    
    private void placeShips() {
    	int SHIPS = 5;//Number of ships used in the battle ship game
    	int count = 0;
    	Random random = new Random();
    	
    	while (count <SHIPS) {
    		
    		int size = random.nextInt(1, 6);//Get size of ship ranging from 1 till 5 inclusive
    		
    		//Start position of ship
    		int row = random.nextInt(0, 10);//Get x coordinate
    		int col = random.nextInt(0, 10);//Get y coordinate
    		
    		if (canBePlaced(row, col, size)) { 
    			for (int i =col; i<col+size; i++) {//Place ships in places
    				grid[row][i] = 'S';
    			}
    			
    			count ++;
    		}
    		
    	}
    	
  
    }
    
    public boolean canBePlaced(int row, int col, int size) { //Used to check if ship can be placed on column
    	
    	if (col+size > 9 || grid[row][col] == 'S') {//Check if ship will surpass board or space is taken
    		return false;
    	}
    	else{
    		
    		for (int i= col; i<size+col; i++) { //Check if all spaces are free
    			if (grid[row][i] == 'S') { //If space is used then return false
    				return false;
    			}
 
    		}
    		
    		return true; //If passes all the tests then return true
    		
    	}
    }
    
    public void print() {
    	
    	System.out.print("\t"); 
    	for (int i=0; i<10; i++) { //Print row numbers
    		System.out.print(" "+i+" ");
    	}
    	
    	System.out.println();
    	for (int i =0; i<10; i++) {
    		System.out.print(i+"\t");
    		for (int j =0; j<10; j++) {
    			if (grid[i][j] == 'M') {
    				System.out.print("[M]");
    			}
    			else if (grid[i][j] == 'H') {
    				System.out.print("[H]");
    			}
    			else {
    				System.out.print("[ ]");
    			}
    			
    		}
    		System.out.println();
    	}
    	
    	
    }
    
    public boolean canFire(int row, int col) {
    	
    	if (row >9 || col > 9 || row<0 || col <0) {
    		return false;
    	}
    	
    	if (grid[row][col] == 'M' || grid[row][col] == 'H') {
    		return false;
    	}
    	else {
    		return true;
    	}
    	
    }
    
    public void processFire(int row, int col) {
    	if (grid[row][col] == 'S') {
    		grid[row][col] = 'H';
    	}
    	else {
    		grid[row][col] = 'M';
    	}
    }
    
    public boolean gameOver() {
    	
    	for (int i =0; i<10; i++) {
    		for (int j =0; j<10; j++) {
    			if (grid[i][j] == 'S') {
    				return false;
    			}
    		}
    	}
    	
    	return true;
    	
    }
    
    
}
