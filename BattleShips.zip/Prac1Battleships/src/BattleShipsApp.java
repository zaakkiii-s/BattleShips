import java.util.Scanner;

public class BattleShipsApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO: Add your code here
		
		BattleShips game = new BattleShips();
		
		while (!game.gameOver()) {//While game isnt over
			game.print();//Print game board
			
			String DO = "\033[0;1m"+"do"; //Tried to make do bold but it didnt work
			
			//Asking user for input
			System.out.println("What row and column "+DO+" you want to fire on?");
			System.out.print("row (0-9): ");
			int row = sc.nextInt();
			System.out.print("col (0-9): ");
			int col = sc.nextInt();
			
			//Validation, chceks if input is valid and if user can fire on that point
			if (game.canFire(row, col)) {
				game.processFire(row, col);
			}
			else {
				System.out.println("Invalid fire retry");
			}
		}
		
		System.out.println("----------------------------------------------------------");
		System.out.println();
		System.out.println("All ships have been hit!!!!!!!!");
		
		System.out.println("============================================================");
		System.out.println("=======================!GAME OVER!==========================");
		System.out.println("============================================================");
	}
}
